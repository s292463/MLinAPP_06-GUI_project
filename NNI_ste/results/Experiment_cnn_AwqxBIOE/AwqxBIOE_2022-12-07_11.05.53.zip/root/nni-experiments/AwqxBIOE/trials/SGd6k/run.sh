#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='AwqxBIOE'
export NNI_SYS_DIR='/root/nni-experiments/AwqxBIOE/trials/SGd6k'
export NNI_TRIAL_JOB_ID='SGd6k'
export NNI_OUTPUT_DIR='/root/nni-experiments/AwqxBIOE/trials/SGd6k'
export NNI_TRIAL_SEQ_ID='13'
export NNI_CODE_DIR='/content/drive/.shortcut-targets-by-id/1wXg2dci4kAWzFZAvhlShcmwk3t0dUHTP/MLinApp_project_mine/NNI_ste/experiments'
export CUDA_VISIBLE_DEVICES='0'
cd $NNI_CODE_DIR
eval python nni_cnn_old.py 2>"/root/nni-experiments/AwqxBIOE/trials/SGd6k/stderr"
echo $? `date +%s%3N` >'/root/nni-experiments/AwqxBIOE/trials/SGd6k/.nni/state'