#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='BYb0Vo26'
export NNI_SYS_DIR='/root/nni-experiments/BYb0Vo26/trials/e6fyu'
export NNI_TRIAL_JOB_ID='e6fyu'
export NNI_OUTPUT_DIR='/root/nni-experiments/BYb0Vo26/trials/e6fyu'
export NNI_TRIAL_SEQ_ID='9'
export NNI_CODE_DIR='/content/drive/.shortcut-targets-by-id/1wXg2dci4kAWzFZAvhlShcmwk3t0dUHTP/MLinApp_project_mine/NNI_ste/experiments'
export CUDA_VISIBLE_DEVICES='0'
cd $NNI_CODE_DIR
eval python nni_scnn.py 2>"/root/nni-experiments/BYb0Vo26/trials/e6fyu/stderr"
echo $? `date +%s%3N` >'/root/nni-experiments/BYb0Vo26/trials/e6fyu/.nni/state'